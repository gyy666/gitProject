# License_plate_recognition
# 车牌识别项目

测试平台
----
- Python 3.6
- PyQt5：5.11.3
- opencv-python：3.4.3
----
- Python 3.7
- PyQt5：5.11.3
- opencv-python：4.2.0
